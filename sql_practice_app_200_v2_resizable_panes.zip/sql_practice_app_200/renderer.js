

// CodeMirror (SQL editor + autocomplete)
const CodeMirror = require("codemirror");
require("codemirror/mode/sql/sql");
require("codemirror/addon/hint/show-hint");
require("codemirror/addon/hint/sql-hint");
require("codemirror/addon/edit/matchbrackets");

const fs = require('fs');
const path = require('path');
const initSqlJs = require('sql.js');

// Optional chart support (offline)
let ChartJS = null;
try {
  // chart.js/auto exports a Chart constructor that registers all controllers/scales
  ChartJS = require('chart.js/auto');
} catch (e) {
  ChartJS = null;
}

const $ = (id) => document.getElementById(id);

const state = {
  SQL: null,
  db: null,
  exercises: [],
  filtered: [],
  current: null,
  level: "All",
  tab: "result",
  logs: [],
  lastResult: null,
  schemaCache: null,
  chartInstance: null,
  settings: null,
  completed: {},
  favorites: {},
};

const SETTINGS_KEY = "sql_practice_settings_v2";
const DEFAULT_SETTINGS = { theme: "light", uiFont: 14, promptFont: 14, codeFont: 13, autocomplete: true, leftW: 370, bottomH: 240 };




const FAVORITES_KEY = "sql_practice_favorites_v1";

function loadFavorites() {
  try {
    const raw = localStorage.getItem(FAVORITES_KEY);
    if (!raw) return {};
    const obj = JSON.parse(raw);
    return (obj && typeof obj === "object") ? obj : {};
  } catch {
    return {};
  }
}

function saveFavorites(map) {
  try {
    localStorage.setItem(FAVORITES_KEY, JSON.stringify(map || {}));
  } catch {}
}

function toggleFavorite(id) {
  if (!id) return;
  state.favorites[id] = !state.favorites[id];
  saveFavorites(state.favorites);
  renderList();
  // If user is on Favorites tab, refresh it
  if (state.tab === "favorites") renderFavorites();
  // Update the action button label
  updateFavoriteButton();
}

function updateFavoriteButton() {
  const btn = $("favorite");
  if (!btn || !state.current) return;
  const isFav = !!state.favorites[state.current.id];
  btn.textContent = isFav ? "★ Favorited" : "☆ Favorite";
}
const COMPLETED_KEY = "sql_practice_completed_v1";

function loadCompleted() {
  try {
    const raw = localStorage.getItem(COMPLETED_KEY);
    if (!raw) return {};
    const obj = JSON.parse(raw);
    return (obj && typeof obj === "object") ? obj : {};
  } catch {
    return {};
  }
}

function saveCompleted(map) {
  try {
    localStorage.setItem(COMPLETED_KEY, JSON.stringify(map || {}));
  } catch {}
}

function markCompleted(id, done = true) {
  if (!id) return;
  state.completed[id] = !!done;
  saveCompleted(state.completed);
  renderList();
}

function loadSettings() {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return { ...DEFAULT_SETTINGS };
    const s = JSON.parse(raw);
    const clamp = (v, lo, hi, d) => Number.isFinite(+v) ? Math.min(hi, Math.max(lo, +v)) : d;
    return {
      theme: ["light","dark","system"].includes(s.theme) ? s.theme : DEFAULT_SETTINGS.theme,
      uiFont: clamp(s.uiFont, 11, 22, DEFAULT_SETTINGS.uiFont),
      promptFont: clamp(s.promptFont, 11, 24, DEFAULT_SETTINGS.promptFont),
      codeFont: clamp(s.codeFont, 11, 22, DEFAULT_SETTINGS.codeFont),
      autocomplete: (typeof s.autocomplete === "boolean") ? s.autocomplete : DEFAULT_SETTINGS.autocomplete,
      leftW: clamp(s.leftW, 260, 650, DEFAULT_SETTINGS.leftW),
      bottomH: clamp(s.bottomH, 140, 520, DEFAULT_SETTINGS.bottomH),
    };
  } catch {
    return { ...DEFAULT_SETTINGS };
  }
}

function saveSettings(s) {
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(s));
}

function applySettings(s) {
  document.body.dataset.theme = s.theme;
  document.documentElement.style.setProperty("--ui-font", s.uiFont + "px");
  document.documentElement.style.setProperty("--prompt-font", s.promptFont + "px");
  document.documentElement.style.setProperty("--code-font", s.codeFont + "px");
  document.documentElement.style.setProperty("--left-w", s.leftW + "px");
  document.documentElement.style.setProperty("--bottom-h", s.bottomH + "px");
  const themeSel = $("themeSel");
  if (themeSel) themeSel.value = s.theme;
  const ac = $("acToggle");
  if (ac) ac.checked = !!s.autocomplete;
}


function getUserSQL() {
  if (state.cm) return state.cm.getValue();
  return $("sql").value;
}

function setUserSQL(v) {
  const val = v || "";
  if (state.cm) state.cm.setValue(val);
  else $("sql").value = val;
}

function buildCompletionTables() {
  // Build a { tableName: [col1, col2, ...] } map for CodeMirror SQL hints
  const tables = {};
  const res = state.db.exec(`
    SELECT name FROM sqlite_master
    WHERE type='table' AND name NOT LIKE 'sqlite_%'
    ORDER BY name;
  `);
  if (!res.length) return tables;
  for (const row of res[0].values) {
    const t = row[0];
    const cols = state.db.exec(`PRAGMA table_info(${t});`);
    if (cols.length) {
      tables[t] = cols[0].values.map(r => r[1]); // name at index 1
    } else {
      tables[t] = [];
    }
  }
  return tables;
}

function initSqlEditor() {
  const ta = $("sql");
  if (!ta || state.cm) return;

  const hintTables = buildCompletionTables();
  state.cmHintTables = hintTables;

  state.cm = CodeMirror.fromTextArea(ta, {
    mode: "text/x-sql",
    lineNumbers: true,
    matchBrackets: true,
    lineWrapping: true,
    autofocus: true,
    indentUnit: 2,
    tabSize: 2,
    extraKeys: {
      "Ctrl-Space": (cm) => {
        if (!state.settings?.autocomplete) return;
        cm.showHint({ completeSingle: false, hint: CodeMirror.hint.sql, tables: state.cmHintTables });
      }
    },
    hintOptions: {
      hint: CodeMirror.hint.sql,
      tables: hintTables
    }
  });

  // Auto trigger suggestions while typing (if enabled)
  state.cm.on("inputRead", (cm, change) => {
    if (!state.settings?.autocomplete) return;
    if (!change || !change.text || !change.text.join("")) return;
    const ch = change.text.join("");
    if (!/[A-Za-z0-9_.]/.test(ch)) return;
    cm.showHint({ completeSingle: false, hint: CodeMirror.hint.sql, tables: state.cmHintTables });
  });
}



function initSplitters() {
  const v = $("vSplit");
  const h = $("hSplit");
  if (!v || !h) return;

  // Vertical splitter (left list width)
  v.addEventListener("mousedown", (e) => {
    e.preventDefault();
    const startX = e.clientX;
    const startW = state.settings.leftW;

    const onMove = (ev) => {
      const dx = ev.clientX - startX;
      const next = Math.min(650, Math.max(260, startW + dx));
      state.settings.leftW = next;
      applySettings(state.settings);
      saveSettings(state.settings);
      if (state.cm) state.cm.refresh();
    };

    const onUp = () => {
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup", onUp);
    };

    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
  });

  // Horizontal splitter (bottom panel height)
  h.addEventListener("mousedown", (e) => {
    e.preventDefault();
    const startY = e.clientY;
    const startH = state.settings.bottomH;

    const onMove = (ev) => {
      const dy = ev.clientY - startY;
      // Dragging down increases bottom height; dragging up decreases
      const next = Math.min(520, Math.max(140, startH - dy));
      state.settings.bottomH = next;
      applySettings(state.settings);
      saveSettings(state.settings);
      if (state.cm) state.cm.refresh();
      if (state.chart) state.chart.resize();
    };

    const onUp = () => {
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup", onUp);
    };

    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
  });
}



function log(msg) {
  const t = new Date().toISOString().replace('T',' ').replace('Z','');
  state.logs.unshift(`[${t}] ${msg}`);
  if (state.tab === "log") renderLog();
}

function setStatus(kind, text) {
  const dot = $("dot");
  dot.classList.remove("ok","bad","neutral");
  if (kind === "ok") dot.classList.add("ok");
  if (kind === "bad") dot.classList.add("bad");
  if (kind === "neutral") dot.classList.add("neutral");
  $("statusText").textContent = text;
}

function escapeHtml(s) {
  return String(s)
    .replaceAll("&","&amp;")
    .replaceAll("<","&lt;")
    .replaceAll(">","&gt;")
    .replaceAll('"',"&quot;")
    .replaceAll("'","&#039;");
}

function isSafe(sql) {
  const s = sql.trim().toUpperCase();
  if (!s) return false;

  // allow only SELECT/WITH queries
  const first = s.match(/^([A-Z]+)/);
  if (!first) return false;
  if (!(first[1] === "SELECT" || first[1] === "WITH")) return false;

  // protect the embedded DB (and keep training focused)
  const banned = [
    "INSERT","UPDATE","DELETE","DROP","ALTER","CREATE","PRAGMA","ATTACH","DETACH",
    "REINDEX","VACUUM","TRIGGER"
  ];
  for (const kw of banned) {
    const re = new RegExp(`\\b${kw}\\b`, "i");
    if (re.test(s)) return false;
  }
  return true;
}

function execQuery(sql) {
  const res = state.db.exec(sql);
  if (!res || res.length === 0) return { columns: [], values: [] };
  return { columns: res[0].columns, values: res[0].values };
}

function normalizeResult(r) {
  const vals = r.values.map(row => row.map(v => {
    if (v === null || v === undefined) return null;
    if (typeof v === "number") return Number.isFinite(v) ? Number(v.toFixed(6)) : v;

    // try numeric
    const n = Number(v);
    if (!Number.isNaN(n) && String(v).trim() !== "") {
      if (/^0\d+/.test(String(v).trim())) return String(v); // preserve leading zeros
      return Number(n.toFixed(6));
    }
    return String(v);
  }));
  return { columns: r.columns, values: vals };
}

function sortRows(values) {
  // Lexicographic sort for stable comparison when order does not matter
  const key = (row) => row.map(v => v === null ? "␀" : String(v)).join("␟");
  return values.slice().sort((a,b) => key(a).localeCompare(key(b)));
}

function sameResult(actual, expected, orderMatters=true) {
  if (actual.columns.length !== expected.columns.length) return false;

  const aVals = orderMatters ? actual.values : sortRows(actual.values);
  const eVals = orderMatters ? expected.values : sortRows(expected.values);

  if (aVals.length !== eVals.length) return false;

  for (let i=0;i<aVals.length;i++) {
    const ra = aVals[i];
    const rb = eVals[i];
    if (ra.length !== rb.length) return false;
    for (let j=0;j<ra.length;j++) {
      if (ra[j] !== rb[j]) return false;
    }
  }
  return true;
}

function renderTable(r) {
  if (!r.columns || r.columns.length === 0) {
    $("out").innerHTML = "<div class='mono'>No rows.</div>";
    return;
  }
  let html = "<table><thead><tr>";
  for (const c of r.columns) html += `<th>${escapeHtml(c)}</th>`;
  html += "</tr></thead><tbody>";
  for (const row of r.values) {
    html += "<tr>";
    for (const v of row) html += `<td>${escapeHtml(v === null ? "NULL" : v)}</td>`;
    html += "</tr>";
  }
  html += "</tbody></table>";
  $("out").innerHTML = html;
}

function renderAnswer() {
  if (!state.current) return;
  $("out").innerHTML = `<div class="mono">${escapeHtml(state.current.solution)}</div>`;
}

function renderHints() {
  if (!state.current) return;
  const hint = state.current.hint ? escapeHtml(state.current.hint) : "No hint for this exercise.";
  const chart = state.current.chart
    ? `<div style="margin-top:10px; color: var(--muted); font-size:12px;">Suggested chart: <b>${escapeHtml(state.current.chart.type)}</b> (x: <code>${escapeHtml(state.current.chart.x)}</code>, y: <code>${escapeHtml(state.current.chart.y)}</code>)</div>`
    : `<div style="margin-top:10px; color: var(--muted); font-size:12px;">Suggested chart: none</div>`;
  $("out").innerHTML = `<div style="white-space: pre-wrap;">${hint}</div>${chart}`;
}


function renderFavorites() {
  const out = $("out");
  const favIds = Object.keys(state.favorites || {}).filter(k => state.favorites[k]);
  const fav = state.exercises.filter(ex => favIds.includes(String(ex.id)));

  if (!fav.length) {
    out.innerHTML = `
      <div class="mono">
        <h3>Favorites</h3>
        <p>You have no favorites yet. Click the ☆ star in the left list (or the Favorite button) to add exercises here.</p>
      </div>
    `;
    return;
  }

  const rows = fav
    .sort((a,b) => a.id - b.id)
    .map(ex => `
      <div class="item" style="cursor:default;">
        <div class="t">
          <span class="titleText">${escapeHtml(ex.title)}</span>
          <span class="badge">#${ex.id}</span>
          <span class="badge favBadge">Fav</span>
        </div>
        <div class="meta">
          <span class="badge">${escapeHtml(ex.level)}</span>
          <span style="margin-left:auto; display:flex; gap:8px;">
            <button class="btn primary" data-open="${ex.id}">Open</button>
            <button class="btn" data-unfav="${ex.id}">Remove</button>
          </span>
        </div>
      </div>
    `).join("");

  out.innerHTML = `
    <div class="mono">
      <h3>Favorites</h3>
      <p>Click <b>Open</b> to jump to an exercise. Click <b>Remove</b> to unfavorite it.</p>
    </div>
    <div style="padding:12px;">${rows}</div>
  `;

  out.querySelectorAll("button[data-open]").forEach(b => {
    b.addEventListener("click", () => {
      const id = Number(b.getAttribute("data-open"));
      selectExercise(id);
      setTab("result");
    });
  });

  out.querySelectorAll("button[data-unfav]").forEach(b => {
    b.addEventListener("click", () => {
      const id = Number(b.getAttribute("data-unfav"));
      toggleFavorite(id);
    });
  });
}

function renderDbInfo() {
  const html = `
    <div style="max-width: 1100px;">
      <div style="font-weight:850; font-size:16px; margin-bottom:8px;">Training Database: Mini Commerce + HR</div>
      <div style="color: var(--muted); margin-bottom:12px; line-height:1.55;">
        This app includes a <b>built-in SQLite database</b> (offline). The data models a small company:
        internal HR (departments/employees) and a simple e-commerce system (customers/orders/products).
        You do <b>not</b> need to install any database server.
      </div>

      <div style="font-weight:800; margin: 14px 0 8px;">Key rules</div>
      <ul style="margin-top:0; line-height:1.6;">
        <li>Dates are stored as text in <code>YYYY-MM-DD</code> format.</li>
        <li>Order revenue is computed from line items: <code>order_items.quantity × products.price</code>.</li>
        <li>Only <code>SELECT</code>/<code>WITH</code> queries are allowed inside the editor (to protect the embedded DB).</li>
      </ul>

      <div style="font-weight:800; margin: 14px 0 8px;">Main relationships (ER overview)</div>
      <ul style="margin-top:0; line-height:1.6;">
        <li><code>departments (1) → (many) employees</code> via <code>employees.dept_id</code></li>
        <li><code>customers (1) → (many) orders</code> via <code>orders.customer_id</code></li>
        <li><code>orders (1) → (many) order_items</code> via <code>order_items.order_id</code></li>
        <li><code>products (1) → (many) order_items</code> via <code>order_items.product_id</code></li>
      </ul>

      <div style="color: var(--muted); font-size:12px; margin-top:10px;">
        Open the <b>Schema</b> tab to see tables, columns, foreign keys, and row counts.
      </div>
    </div>
  `;
  $("out").innerHTML = html;
}

function buildSchemaCache() {
  // Use PRAGMA internally (blocked only for user queries).
  const getSingleCol = (sql) => {
    const r = execQuery(sql);
    if (!r.values || r.values.length === 0) return [];
    return r.values.map(x => x[0]);
  };

  const tables = getSingleCol("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name;");
  const out = { tables: [] };

  for (const t of tables) {
    const cols = execQuery(`PRAGMA table_info(${t});`);
    const fks = execQuery(`PRAGMA foreign_key_list(${t});`);
    const cnt = execQuery(`SELECT COUNT(*) AS cnt FROM ${t};`);
    out.tables.push({
      name: t,
      row_count: (cnt.values[0] ? cnt.values[0][0] : 0),
      columns: cols.values.map(r => ({
        cid: r[0], name: r[1], type: r[2],
        notnull: r[3], dflt: r[4], pk: r[5]
      })),
      foreign_keys: fks.values.map(r => ({
        id: r[0], seq: r[1], to_table: r[2], from: r[3], to: r[4],
        on_update: r[5], on_delete: r[6]
      }))
    });
  }
  state.schemaCache = out;
}

function renderSchema() {
  try {
    if (!state.schemaCache) buildSchemaCache();
    const s = state.schemaCache;

    let html = `<div style="max-width:1200px;">`;
    html += `<div style="font-weight:850; font-size:16px; margin-bottom:8px;">Schema & Row Counts</div>`;
    html += `<div style="color: var(--muted); margin-bottom:12px; line-height:1.55;">
      Use this reference while solving exercises. Keys and relationships are shown below.
    </div>`;

    for (const t of s.tables) {
      html += `<div style="margin: 14px 0 8px; font-weight:850;">Table: <code>${escapeHtml(t.name)}</code> <span style="color:var(--muted); font-weight:650;">(${t.row_count} rows)</span></div>`;

      // columns table
      html += `<table><thead><tr>
        <th>Column</th><th>Type</th><th>PK</th><th>Not null</th><th>Default</th>
      </tr></thead><tbody>`;
      for (const c of t.columns) {
        html += `<tr>
          <td><code>${escapeHtml(c.name)}</code></td>
          <td>${escapeHtml(c.type || "")}</td>
          <td>${c.pk ? "✓" : ""}</td>
          <td>${c.notnull ? "✓" : ""}</td>
          <td>${escapeHtml(c.dflt === null ? "" : c.dflt)}</td>
        </tr>`;
      }
      html += `</tbody></table>`;

      // foreign keys
      if (t.foreign_keys.length) {
        html += `<div style="margin-top:8px; color: var(--muted); font-size:12px;"><b>Foreign keys</b></div>`;
        html += `<table><thead><tr><th>From</th><th>References</th><th>On delete</th></tr></thead><tbody>`;
        for (const fk of t.foreign_keys) {
          html += `<tr>
            <td><code>${escapeHtml(fk.from)}</code></td>
            <td><code>${escapeHtml(fk.to_table)}</code>(<code>${escapeHtml(fk.to)}</code>)</td>
            <td>${escapeHtml(fk.on_delete || "")}</td>
          </tr>`;
        }
        html += `</tbody></table>`;
      }
    }

    html += `</div>`;
    $("out").innerHTML = html;
  } catch (e) {
    $("out").innerHTML = `<div class="mono">Failed to render schema: ${escapeHtml(e.message)}</div>`;
  }
}


function renderAbout() {
  const out = $("out");
  out.innerHTML = `
    <div class="mono">
<h3>About</h3>
<p><b>Author:</b> Alireza Abbaspour Kanzagh<br/>
   <b>Email:</b> <a href="mailto:alirezakanzagh76@gmail.com">alirezakanzagh76@gmail.com</a></p>

<h4>What this app is</h4>
<ul>
  <li>Offline SQL practice app with a built-in SQLite database (runs in-browser via sql.js).</li>
  <li>Scenario-based exercises (Easy → Report) with validation, hints, answers, and charts.</li>
  <li>Schema explorer so you can understand tables and relationships without setting up any DB server.</li>
</ul>

<h4>Notes</h4>
<ul>
  <li>For safety, only read-only queries are allowed (SELECT / WITH).</li>
  <li>If you publish this as a portfolio project, include a license and a link to the repo.</li>
</ul>
    </div>
  `;
}


function renderLog() {
  $("out").innerHTML = `<div class="mono">${escapeHtml(state.logs.join("\n"))}</div>`;
}

function destroyChart() {
  try {
    if (state.chartInstance && typeof state.chartInstance.destroy === "function") {
      state.chartInstance.destroy();
    }
  } catch {}
  state.chartInstance = null;
}

function coerceNumber(v) {
  if (v === null || v === undefined) return null;
  if (typeof v === "number") return v;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

function renderChart() {
  const out = $("out");

  if (!state.lastResult || !state.lastResult.columns || state.lastResult.columns.length === 0) {
    out.innerHTML = `<div style="color: var(--muted);">Run a query first (or Validate) to see a chart.</div>`;
    return;
  }

  if (!ChartJS) {
    out.innerHTML = `<div class="mono">Chart.js is not available in this build.</div>`;
    return;
  }

  const cols = state.lastResult.columns;
  const values = state.lastResult.values;

  const suggested = (state.current && state.current.chart) ? state.current.chart : null;

  // Build UI
  out.innerHTML = `
    <div style="display:flex; flex-direction:column; gap:10px;">
      <div style="display:flex; gap:10px; flex-wrap:wrap; align-items:center;">
        <span style="color:var(--muted); font-size:12px;">Chart</span>
        <select id="chartType" class="select">
          <option value="bar">bar</option>
          <option value="line">line</option>
          <option value="pie">pie</option>
        </select>

        <span style="color:var(--muted); font-size:12px;">X</span>
        <select id="chartX" class="select"></select>

        <span style="color:var(--muted); font-size:12px;">Y</span>
        <select id="chartY" class="select"></select>

        <span style="color:var(--muted); font-size:12px;">Rows</span>
        <select id="chartLimit" class="select">
          <option value="25">25</option>
          <option value="50">50</option>
          <option value="100">100</option>
          <option value="999999">All</option>
        </select>

        <button id="chartRender" class="btn primary">Render</button>
        <div style="color:var(--muted); font-size:12px;">
          Tip: for best charts, return a small aggregated table (e.g., month + revenue).
        </div>
      </div>
      <div style="border:1px solid var(--border); border-radius:16px; padding:10px; background:var(--panel); box-shadow: var(--shadow);">
        <canvas id="chartCanvas" height="120"></canvas>
      </div>
    </div>
  `;

  const selX = $("chartX");
  const selY = $("chartY");
  for (const c of cols) {
    selX.insertAdjacentHTML("beforeend", `<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`);
    selY.insertAdjacentHTML("beforeend", `<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`);
  }

  // defaults
  if (suggested && cols.includes(suggested.x)) selX.value = suggested.x;
  else selX.value = cols[0];

  if (suggested && cols.includes(suggested.y)) selY.value = suggested.y;
  else selY.value = cols[Math.min(1, cols.length-1)];

  const typeSel = $("chartType");
  if (suggested && ["bar","line","pie"].includes(suggested.type)) typeSel.value = suggested.type;

  const renderNow = () => {
    destroyChart();

    const xName = selX.value;
    const yName = selY.value;
    const type = typeSel.value;
    const limit = Number($("chartLimit").value);

    const xi = cols.indexOf(xName);
    const yi = cols.indexOf(yName);

    const slice = values.slice(0, limit);
    const labels = slice.map(r => r[xi] === null ? "NULL" : String(r[xi]));
    const nums = slice.map(r => coerceNumber(r[yi]));

    // If Y is not numeric, just show message
    if (nums.some(v => v === null)) {
      out.querySelector("#chartCanvas").replaceWith(document.createElement("div"));
      out.querySelector("div").textContent = "";
      const msg = document.createElement("div");
      msg.style.color = "var(--muted)";
      msg.style.marginTop = "10px";
      msg.textContent = "Y column must be numeric for charting. Try aggregating (SUM/COUNT) or choose a numeric column.";
      out.appendChild(msg);
      return;
    }

    // rebuild canvas (we might have replaced it)
    const wrap = out.querySelector("canvas") ? out.querySelector("canvas").parentElement : out.querySelector("div[style*='border:1px']");
    wrap.innerHTML = `<canvas id="chartCanvas" height="120"></canvas>`;
    const ctx = $("chartCanvas").getContext("2d");

    const config = {
      type,
      data: {
        labels,
        datasets: [{
          label: yName,
          data: nums,
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: type === "pie" },
          tooltip: { enabled: true }
        },
        scales: (type === "pie") ? {} : {
          x: { ticks: { autoSkip: true, maxRotation: 0 } },
          y: { beginAtZero: true }
        }
      }
    };

    state.chartInstance = new ChartJS(ctx, config);
  };

  $("chartRender").onclick = renderNow;
  renderNow();
}

function setTab(tab) {
  state.tab = tab;

  $("tabResult").classList.toggle("active", tab === "result");
  $("tabChart").classList.toggle("active", tab === "chart");
  $("tabAnswer").classList.toggle("active", tab === "answer");
  $("tabHints").classList.toggle("active", tab === "hints");
  $("tabFav").classList.toggle("active", tab === "favorites");
  $("tabDbInfo").classList.toggle("active", tab === "dbinfo");
  $("tabSchema").classList.toggle("active", tab === "schema");
  $("tabAbout").classList.toggle("active", tab === "about");
  $("tabLog").classList.toggle("active", tab === "log");

  if (tab === "answer") renderAnswer();
  else if (tab === "hints") renderHints();
  else if (tab === "favorites") renderFavorites();
  else if (tab === "dbinfo") renderDbInfo();
  else if (tab === "schema") renderSchema();
  else if (tab === "about") renderAbout();
  else if (tab === "chart") renderChart();
  else if (tab === "log") renderLog();
  // "result" is rendered by run/validate
}

function renderList() {
  const list = $("list");
  list.innerHTML = "";
  for (const ex of state.filtered) {
    const div = document.createElement("div");
    const done = !!state.completed[ex.id];
    const fav = !!state.favorites[ex.id];

    div.className =
      "item" +
      (state.current && state.current.id === ex.id ? " active" : "") +
      (done ? " done" : "");

    div.innerHTML = `
      <div class="t">
        <span class="titleText">${escapeHtml(ex.title)}</span>
        ${fav ? `<span class="favMark" data-id="${ex.id}" title="Unfavorite">★</span>` : `<span class="favMark" data-id="${ex.id}" title="Favorite">☆</span>`}
        ${done ? `<span class="doneMark" data-id="${ex.id}" title="Mark as not done">✓</span>` : `<span class="doneMark" data-id="${ex.id}" title="Mark as done">○</span>`}
      </div>
      <div class="meta">
        <span class="badge">${escapeHtml(ex.level)}</span>
        <span class="badge">#${ex.id}</span>
        ${fav ? `<span class="badge favBadge">Fav</span>` : ``}
        ${done ? `<span class="badge doneBadge">Done</span>` : ``}
      </div>
    `;

    // Click on the card selects the exercise
    div.onclick = () => selectExercise(ex.id);

    // Click on star toggles favorite (does not select)
    const star = div.querySelector(".favMark");
    if (star) {
      star.addEventListener("click", (e) => {
        e.stopPropagation();
        toggleFavorite(ex.id);
      });
    }

    // Click on done mark toggles completed (does not select)
    const doneEl = div.querySelector(".doneMark");
    if (doneEl) {
      doneEl.addEventListener("click", (e) => {
        e.stopPropagation();
        const now = !!state.completed[ex.id];
        markCompleted(ex.id, !now);
        // If Favorites filter is active, keep list consistent
        if (state.level === "Favorites") applyFilters();
      });
    }

    list.appendChild(div);
  }
}

function applyFilters() {
  const q = $("search").value.trim().toLowerCase();
  state.filtered = state.exercises.filter(ex => {
    const okLevel =
      (state.level === "All") ||
      (state.level === "Favorites" && !!state.favorites[ex.id]) ||
      (ex.level === state.level);

    if (!okLevel) return false;
    if (!q) return true;
    return (ex.title.toLowerCase().includes(q) || ex.prompt.toLowerCase().includes(q));
  });
  renderList();
}

function selectExercise(id) {
  const ex = state.exercises.find(x => x.id === id);
  if (!ex) return;
  state.current = ex;
  $("qTitle").textContent = ex.title;
  $("qPrompt").innerHTML = ex.prompt;
  setUserSQL(ex.starter || "");
  state.lastResult = null;
  setStatus("neutral", "Ready");
  updateFavoriteButton();
  setTab("result");
  renderList();
  log(`Selected exercise #${ex.id}`);
}

async function loadApp() {
  try {
    const initPath = path.join(__dirname, "data", "init.sql");
    const exPath = path.join(__dirname, "data", "exercises.json");

    const initSql = fs.readFileSync(initPath, "utf-8");
    const exercises = JSON.parse(fs.readFileSync(exPath, "utf-8"));

    const SQL = await initSqlJs({
      locateFile: (file) => path.join(__dirname, "node_modules", "sql.js", "dist", file),
    });

    state.SQL = SQL;
    state.db = new SQL.Database();
    state.db.run(initSql);

    state.exercises = exercises;
    state.filtered = exercises.slice();

    // Settings
    state.settings = loadSettings();
    state.completed = loadCompleted();
    state.favorites = loadFavorites();
    applySettings(state.settings);
      initSqlEditor();
      initSplitters();

    $("themeSel").addEventListener("change", (e) => {
      state.settings.theme = e.target.value;
      applySettings(state.settings);


$("acToggle").addEventListener("change", (e) => {
  state.settings.autocomplete = !!e.target.checked;
  applySettings(state.settings);
  saveSettings(state.settings);
  log("Autocomplete " + (state.settings.autocomplete ? "enabled" : "disabled"));
});
      initSqlEditor();
      initSplitters();
      saveSettings(state.settings);
      log("Theme set to " + state.settings.theme);
    });

    const bump = (key, delta, lo, hi) => {
      state.settings[key] = Math.min(hi, Math.max(lo, state.settings[key] + delta));
      applySettings(state.settings);
      initSqlEditor();
      initSplitters();
      saveSettings(state.settings);
    };

    $("uiMinus").onclick = () => bump("uiFont", -1, 11, 22);
    $("uiPlus").onclick = () => bump("uiFont", +1, 11, 22);
    $("promptMinus").onclick = () => bump("promptFont", -1, 11, 24);
    $("promptPlus").onclick = () => bump("promptFont", +1, 11, 24);
    $("codeMinus").onclick = () => bump("codeFont", -1, 11, 22);
    $("codePlus").onclick = () => bump("codeFont", +1, 11, 22);
    $("resetView").onclick = () => {
      state.settings = { ...DEFAULT_SETTINGS };
      applySettings(state.settings);
      initSqlEditor();
      initSplitters();
      saveSettings(state.settings);
      log("View settings reset");
    };

    // Search + filters
    $("search").addEventListener("input", applyFilters);
    for (const pill of document.querySelectorAll(".pill")) {
      pill.addEventListener("click", () => {
        document.querySelectorAll(".pill").forEach(p => p.classList.remove("active"));
        pill.classList.add("active");
        state.level = pill.dataset.level;
        applyFilters();
      });
    }

    // Tabs
    $("tabResult").onclick = () => setTab("result");
    $("tabChart").onclick = () => setTab("chart");
    $("tabAnswer").onclick = () => setTab("answer");
    $("tabHints").onclick = () => setTab("hints");
    $("tabFav").onclick = () => setTab("favorites");
    $("tabDbInfo").onclick = () => setTab("dbinfo");
    $("tabSchema").onclick = () => setTab("schema");
    $("tabLog").onclick = () => setTab("log");

    // Run
    $("run").onclick = () => {
      if (!state.current) return;
      const sql = getUserSQL();
      if (!isSafe(sql)) {
        setStatus("bad", "Blocked: only SELECT/WITH queries are allowed.");
        log("Blocked unsafe query");
        setTab("log");
        return;
      }
      try {
        const r = normalizeResult(execQuery(sql));
        state.lastResult = r;
        setTab("result");
        renderTable(r);
        setStatus("ok", "Query ran successfully.");
        log("Run OK");
      } catch (e) {
        setStatus("bad", "Error: " + e.message);
        log("Run error: " + e.message);
        setTab("log");
      }
    };

    // Validate
    $("validate").onclick = () => {
      if (!state.current) return;
      const userSql = getUserSQL();
      if (!isSafe(userSql)) {
        setStatus("bad", "Blocked: only SELECT/WITH queries are allowed.");
        log("Validate blocked unsafe query");
        setTab("log");
        return;
      }
      try {
        const expected = normalizeResult(execQuery(state.current.validation.answerQuery));
        const actual = normalizeResult(execQuery(userSql));

        const orderMatters = (state.current.validation && typeof state.current.validation.orderMatters === "boolean")
          ? state.current.validation.orderMatters
          : true;

        const ok = sameResult(actual, expected, orderMatters);

        state.lastResult = actual;

        setTab("result");
        renderTable(actual);

        if (ok) {
          setStatus("ok", "✅ Correct (matches expected output)");
          markCompleted(state.current.id, true);
          log("Validate OK");
        } else {
          setStatus("bad", "❌ Not matching. You can use Hints or Show Answer.");
          log("Validate mismatch");
        }
      } catch (e) {
        setStatus("bad", "Error: " + e.message);
        log("Validate error: " + e.message);
        setTab("log");
      }
    };

$("favorite").onclick = () => {
  if (!state.current) return;
  toggleFavorite(state.current.id);
};


    // Show Answer
    $("answer").onclick = () => {
      if (!state.current) return;
      setTab("answer");
      setStatus("ok", "Showing official answer.");
      log("Show answer");
    };

    // Pick first
    selectExercise(1);
    setStatus("neutral", "Ready.");
    log("App ready");
  } catch (e) {
    setStatus("bad", "Failed to load: " + e.message);
    log("Fatal: " + e.message);
    setTab("log");
  }
}

loadApp();
