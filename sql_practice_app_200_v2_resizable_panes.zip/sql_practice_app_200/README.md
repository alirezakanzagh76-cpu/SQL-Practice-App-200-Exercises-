# SQL Practice App (Offline) — 200 Exercises

An offline SQL training app.

✅ Built-in database: SQLite (via sql.js)  
✅ 200 exercises + official answers  
✅ Buttons: Run / Validate / Show Answer  
✅ No MySQL/Postgres/server required  

## Run (Dev)
```bash
npm install
npm start
```

## Build an installable app (optional)
```bash
npm run dist
```

## Safety
Only `SELECT` and `WITH` queries are allowed (to keep the database unchanged).



## UI
- Theme selector: Light / System / Dark
- Font controls: UI / Prompt / Code
- Tabs: Result, Chart, Answer, Hints, Database Info, Schema, Log

## Database
- Tables: departments, employees, customers, orders, order_items, products
- Dates: stored as TEXT in YYYY-MM-DD
- Revenue: order_items.quantity × products.price

- Resizable panes: drag the vertical/horizontal splitter bars.
